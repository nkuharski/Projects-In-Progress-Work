function convert () {
    // console.log("convert function called");

    let amount = document.forms["conversion"]["amount"].value;

    if (isANumber(amount)) {

        let unit_from = document.forms["conversion"]["unit_from"].value;
        let unit_to = document.forms["conversion"]["unit_to"].value;

        //if units are the same, no need to convert
        if (unit_from == unit_to) {
            document.getElementById("output").innerHTML = amount + " " + unit_from;
        } else {
            const toSeconds = new Map([
                ["seconds", 1],
                ["minutes", 60],
                ["hours", 3600],
                ["days", 86400],
                ["weeks", 604800]
            ]);

            // get conversion rate from unit_from
            let secRate = toSeconds.get(unit_from);

            let sec = secRate * amount;

            let toRate = toSeconds.get(unit_to);

            let outputAmount = sec / toRate;

            if (output % 1 != 0) {
                //round to two
                outputAmount = outputAmount.toFixed(2);
            }

            //output result
            document.getElementById("output").innerHTML = outputAmount + " " + unit_to;
        } 
    } else {
        // if the amount is not a number, give error
        document.getElementById("output").innerHTML = "Please enter a valid number.";
    }
}

function isANumber(text) {
    // this is a regular expression that accepts only numbers
    let regex=/^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)$/;
    if (text.match(regex)) {
        return true;
    } else {
        return false;
    }
}