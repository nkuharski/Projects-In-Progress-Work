function changeElementClass(id, newClass) {
    //changes the class element identified by id to NewClass
    document.getElementById(id).className = newClass;
}

function changeText(id, newText) {
    //changes the class element identified by id to newText
    document.getElementById(id).innerHTML = newText;
}