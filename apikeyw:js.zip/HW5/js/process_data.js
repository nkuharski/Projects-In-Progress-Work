/**
 * Uses fetch() to get data from Census API
 * Uses API key stored in key.js under const apiKey
 */
function getData() {
    
    let year = document.forms["test"]["year"].value;

    const apiURL = "https://api.census.gov/data/timeseries/bds?get=NAME,NET_JOB_CREATION&for=state&YEAR=" + year + "&key=" + apiKey;

    // make an asynchronous call to get the data
    // fetch returns a promise that will include a full https response
    // we then extract json from it, which is another asynchronous call taht returns a promise
    // we process the json data through the showData function
    fetch(apiURL)
        .then(response => response.json())
        .then(showData);
}

function showData(data) {
    // receives JSON data and outputs it as a table

    // we should have an array of arrays

    // we don't need the first element, which is just headers
    dataNoHeader = data.slice(1);

    // sort it so states show up in the right order
    dataNoHeader = dataNoHeader.sort();

    // set up table with header
    output = "<table class='table table-hover table-responsive w-auto'>";
    output += "<thead><tr><th>State</th><th class='text-end'>Net Jobs Created</th></tr></thead>";

    // start table body
    output += "<tbody>";

    // process each state
    for (state of dataNoHeader) {
        let stateName = state[0];
        let net_jobs = Number(state[1]);
        let net_jobsTXT = new Intl.NumberFormat('en-US').format(net_jobs);

        // use string templates
        // first element is state name, 2nd is density, 3rd is population
        output += `<tr><td>${stateName}</td><td class="text-end font-monospace">${net_jobsTXT}</td></tr>`;
    }

    // end body and table
    output += "</tbody></table>";

    changeText("output", output);
}
